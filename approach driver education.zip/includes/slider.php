<!-- Hero Slide Area
============================================ -->
<div id="hero-area" class="hero-slider-area">
	<div id="hero-slider" class="nivoSlider slider-image">
		<img src="img/slider/1.jpg" alt="main slider" title="#htmlcaption1"/>
		<img src="img/slider/2.jpg" alt="main slider" title="#htmlcaption2"/>
		<img src="img/slider/3.jpg" alt="main slider" title="#htmlcaption3"/>
	</div>
	<div id="htmlcaption1" class="nivo-html-caption">			
		<div class="slide-table container">
			<div class="table-cell">
				<div class="hero-slide-content float-right text-right">
					<h3 class="wow fadeInUp" data-wow-duration=".9s" data-wow-delay="0.8s">welcome to approach driver education</h3>
					<h1 class="wow fadeInUp" data-wow-duration=".9s" data-wow-delay="1.2s">the best <span>Driving school</span></h1>
					<h3 class="wow fadeInUp" data-wow-duration=".9s" data-wow-delay="1.6s">With High Pass Rate</h3>
					<div class="button-group">
						<a href="contact.php" class="btn transparent wow fadeInLeft" data-wow-duration=".9s" data-wow-delay="2.4s">book lesson</a>
						<a href="about.php" class="btn color wow fadeInLeft" data-wow-duration=".9s" data-wow-delay="2s">learn more</a>
					</div>
				</div>
			</div>										
		</div>
	</div>
	<div id="htmlcaption2" class="nivo-html-caption">			
		<div class="slide-table container">
			<div class="table-cell">
				<div class="hero-slide-content float-right text-right">
					<h3 class="wow fadeInUp" data-wow-duration=".9s" data-wow-delay="0.8s">Your Perfect Choice</h3>
					<h1 class="wow fadeInUp" data-wow-duration=".9s" data-wow-delay="1.2s">for <span>Driving</span> Lessons</h1>
					<p class="wow fadeInUp" data-wow-duration=".9s" data-wow-delay="1.6s">Much more than Simply providing you the skill to pass your driving test</p>
					<div class="button-group">
						<a href="contact.php" class="btn transparent wow fadeInRight" data-wow-duration=".9s" data-wow-delay="2s">book lesson</a>
						<a href="about.php" class="btn color wow fadeInRight" data-wow-duration=".9s" data-wow-delay="2.4s">learn more</a>
					</div>
				</div>
			</div>										
		</div>
	</div>
	<div id="htmlcaption3" class="nivo-html-caption">			
		<div class="slide-table container">
			<div class="table-cell">
				<div class="hero-slide-content float-left text-left">
					<h3 class="wow fadeInUp" data-wow-duration=".9s" data-wow-delay="0.8s">Do you want to Learn</h3>
					<h1 class="wow fadeInUp" data-wow-duration=".9s" data-wow-delay="1.2s">How To <span>Drive</span></h1>
					<p class="wow fadeInUp" data-wow-duration=".9s" data-wow-delay="1.6s">We will teach you in a calm and Professional Style about How to drive safely and competently</p>
					<div class="button-group">
						<a href="contact.php" class="btn transparent wow fadeInRight" data-wow-duration=".9s" data-wow-delay="2s">book lesson</a>
						<a href="about.php" class="btn color wow fadeInRight" data-wow-duration=".9s" data-wow-delay="2.4s">learn more</a>
					</div>
				</div>
			</div>										
		</div>
	</div>
</div>