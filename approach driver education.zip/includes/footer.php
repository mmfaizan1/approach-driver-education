<!-- Footer Area
============================================ -->
<div class="footer-area overlay overlay-black overlay-70 pt-90">
	<div class="container">
		<div class="footer-bottom text-center col-xs-12">
			<p class="copyright">Copyright © 2019. <a href="https://approachdrivereducation.co.uk" target="_blank" >Approach Driver Education.</a> All rights reserved. Website Made by <a href="https://www.facebook.com/mohammad.faizan.zafar">Faizan Zafar</a></p>
		</div>
	</div>
</div>

</div>
<!-- Body main wrapper end -->