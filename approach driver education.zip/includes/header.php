<!-- Body main wrapper start -->
<div class="wrapper wide-layout fix">
<!-- Header 1
============================================ -->
<div class="header-area header-absolute header-transparent">
	<div class="header-top hidden-xs">
		<div class="container">
			<div class="row">
				<!-- Header Top -->
				<div class="header-top-wrapper fix">
					<div class="header-top-left text-left col-sm-6">
						<!-- <p><i class="icofont icofont-envelope"></i><span>info@driveon.com</span></p> -->
						<p><i class="icofont icofont-ui-call"></i><span>+44 7501 400022</span></p>
						<p><i class="icofont icofont-ui-email"></i><span>mkhalid9789@gmail.com</span></p>
					</div>
					<div class="header-top-right text-right col-sm-6">
						<p><i class="icofont icofont-clock-time"></i><span>Mon - Sat : 8am - 9pm</span></p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="header-bottom sticky">
		<div class="container">
			<div class="row">
				<!-- Header Bottom -->
				<div class="col-xs-12">
					<div class="navbar-header">
						<a href="home.php" class="logo navbar-brand"><img id="logo_img" src="img/logo/logo.png" alt="logo" /></a>
					</div>
					<div class="main-menu mean-menu float-right">
						<nav>
							<ul>
								<li class="<?php if($page=='Home'){echo 'active';}?>"><a href="home.php">home</a></li>
								<li class="<?php if($page=='About'){echo 'active';}?>"><a href="about.php">about</a></li>
								<li class="<?php if($page=='Gallery'){echo 'active';}?>"><a href="gallery.php">gallery</a></li>
								<li class="<?php if($page=='Testimonials'){echo 'active';}?>"><a href="testimonials.php">Testimonials</a></li>
								<li class="<?php if($page=='FAQ'){echo 'active';}?>"><a href="faq.php">FAQ</a></li>
								<li class="<?php if($page=='Pricing'){echo 'active';}?>"><a href="pricing.php">Pricing</a></li>
								<li class="<?php if($page=='Contact'){echo 'active';}?>"><a href="contact.php">contact</a></li>
							</ul>
						</nav>
					</div>
					<div class="mobile-menu"></div>
				</div>
			</div>
		</div>
	</div>
</div>
