<?php
$page = "Gallery";
include('includes/top.php');
include('includes/header.php');
?>
<!-- Page Banner Area
============================================ -->
<div class="page-banner-area overlay overlay-black overlay-70">
	<div class="container">
		<div class="row">
			<div class="page-banner text-center col-xs-12">
				<h1>Gallery</h1>
				<!-- <ul>
					<li><a href="#">home</a></li>
					<li><span>about us</span></li>
				</ul> -->
			</div>
		</div>
	</div>
</div>
<!-- Gallery Area
============================================ -->
<div id="gallery-area" class="gallery-area bg-gray pt-90 pb-90">
	<div class="container">
		<!-- Gallery Filter -->
		<div class="gallery-filter text-center">
			<button class="active" data-filter="*">all</button>
			<button data-filter=".cars">cars</button>
			<button data-filter=".students">students</button>
			<!-- <button data-filter=".classroom">classroom</button>
			<button data-filter=".exam">exam</button> -->
		</div>
		<!-- Gallery Grid -->
		<div class="gallery-grid row mb-20">
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-37.jpeg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-37.jpeg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-36.jpeg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-36.jpeg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-35.jpeg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-35.jpeg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-34.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-34.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-32.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-32.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-33.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-33.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-29.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-29.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-30.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-30.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-31.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-31.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-1.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-1.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-2.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-2.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-3.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-3.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item cars col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-4.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-4.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>Car</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-5.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-5.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-6.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-6.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-7.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-7.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-8.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-8.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-9.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-9.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-10.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-10.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-11.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-11.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-12.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-12.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-13.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-13.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-14.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-14.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-15.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-15.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-16.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-16.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item cars students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-17.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-17.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-18.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-18.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students cars col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-19.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-19.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-20.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-20.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-21.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-21.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-22.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-22.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-23.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-23.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-24.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-24.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-25.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-25.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-26.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-26.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item students col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-27.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-27.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>student</h4>
					</div>
				</a>
			</div>
			<div class="gallery-item cars classroom col-md-3 col-sm-4 col-xs-12">
				<a href="img/gallery/gallery-28.jpg" class="gallery-image image-popup">
					<img src="img/gallery/gallery-28.jpg" alt="" />
					<div class="content">
						<i class="icofont icofont-search"></i>
						<h4>Car</h4>
					</div>
				</a>
			</div>
		</div>
		<!-- <div class="pagination text-center">
			<ul>
				<li><a href="#"><i class="icofont icofont-simple-left"></i></a></li>
				<li class="active"><a href="#">1</a></li>
				<li><a href="#">2</a></li>
				<li><a href="#">3</a></li>
				<li><a href="#"><i class="icofont icofont-simple-right"></i></a></li
			</ul>
		</div> -->
	</div>
</div>
<!-- CTA Area
============================================ -->
<div class="cta-area pb-40 pt-40">
	<div class="container">
		<div class="row">
			<div class="call-to-action text-left col-md-10 col-md-offset-1 col-xs-12">
				<h3>Call now to book lesson</h3>
				<a href="tel:+447501400022" class="btn transparent ">get  lesson</a>
			</div>
		</div>
	</div>
</div>
<?php
include('includes/footer.php');
include('includes/bottom.php');
?>