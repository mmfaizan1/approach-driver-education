<?php
$page = "About";
include('includes/top.php');
include('includes/header.php');
?>
<!-- Page Banner Area
============================================ -->
<div class="page-banner-area overlay overlay-black overlay-70">
	<div class="container">
		<div class="row">
			<div class="page-banner text-center col-xs-12">
				<h1>About us</h1>
				<!-- <ul>
					<li><a href="#">home</a></li>
					<li><span>about us</span></li>
				</ul> -->
			</div>
		</div>
	</div>
</div>
<!-- About Area
============================================ -->
<div id="feature-area" class="feature-area bg-gray pt-90 pb-90">
	<div class="container">
		<!-- Section Title -->
		<div class="row">
			<div class="section-title text-center col-xs-12 mb-45">
				<h3 class="heading">about approach driver education</h3>
				<!-- <div class="excerpt">
					<p>Lorem ipsum dolor sit amet, consectetur maksu rez do eiusmod tempor magna aliqua</p>
				</div> -->
				<i class="icofont icofont-traffic-light"></i>
			</div>
		</div>
		<div class="row">
			<p>Approach Driver Education is a family business running since more than 15 years dedicated to safe driving lessons in southall and customer satisfaction.
			No matter what your age or experience, you can be sure of patient, expert tuition. We tailor your driving lesson to suit you personally which means you avoid stress by learning at your own speed.
			We welcome complete novices/nervous drivers, whatever your current driving ability may be; we can devise a plan to prepare you for your test.</p>
			<p>We provide training for both <strong>MANUAL</strong> as well as <strong>AUTOMATIC</strong> Transmission cars.</p>
			<p>We have a great team at Approach Driver Education and our satisfaction guarantee means we can usually offer you a choice of instructors to meet your personal requirements. Our current pass rate is way in excess of the national average. We will collect you from and return you to your home or work place for your lesson (provided you are in the area covered by Approach Driver Education )</p>
			<p>Apart from that here are some reasons that makes us better than anyone else.</p>
			<p>
				<ul>
					<li>1- All instructors are DSA approved</li>
					<li>2- All vehicles have dual controls</li>
					<li>3- Pick-up and drop-off service</li>
					<li>4- Pass plus lessons</li>
					<li>5- Motorway lessons</li>
					<li>6- Refresher course</li>
					<li>7- Block booking</li>
					<li>8- Intensive courses</li>
					<li>9- Lesson prices are fixed</li>
				</ul>
			</p>
			<p>We always provide a modern clean air-conditioned car, with dual controls for your safety. Every effort is made to ensure you always have that same vehicle through all of your lessons right to the test. When you are ready for your driving test we will take you to the Test Centre and wait for you while you take the test in your usual school car. Using a familiar vehicle will give you more confidence and increase your chance of success.</p>
		</div>
	</div>
</div>
<!-- Banner Area
============================================ -->
<div id="feature-area" class="feature-area bg-gray pt-90 pb-90">
	<div class="container">
		<!-- Section Title -->
		<div class="row">
			<div class="section-title text-center col-xs-12 mb-45">
				<img src="img/banner.png">
			</div>
		</div>
	</div>
</div>
<!-- Instructor Area
============================================ -->
<div id="instructor-area" class="instructor-area bg-gray pt-90 pb-60">
	<div class="container">
		<!-- Section Title -->
		<div class="row">
			<div class="section-title text-center col-xs-12 mb-45">
				<h3 class="heading">Instructors</h3>
				<div class="excerpt">
					<p>We have highly qualified and approved instructors from DVSA with Top Grades.</p>
				</div>
				<i class="icofont icofont-traffic-light"></i>
			</div>
		</div>
		<div class="row">
			<div class="col-md-10 col-md-offset-1">
				<!-- Instructor Tab Content -->
				<div class="tab-content">
					<div class="tab-pane fade in active row" id="instructor-1">
						<div class="instructor-details text-left col-md-7 col-xs-12">
							<h4 class="instructor-name">Mohammad Iqbal Khalid</h4>
							<h5 class="instructor-title">Direcor and Lead Instructor</h5>
							<p>Mohammad Khalid is the director of Khalid approach School of Motoring. He is Serving Khalid Approach School of Motoring from over 15 Years. He is Fully Qualified & Approved Driving Instructor.</p>
							<div class="instructor-social fix">
								<a href="https://www.facebook.com/profile.php?id=100007849806151" target="_blank"><i class="icofont icofont-social-facebook"></i></a>
								<a href="mailto:mkhalid9789@gmail.com"><i class="icofont icofont-email"></i></a>
								<a href="tel:+447501400022"><i class="icofont icofont-phone"></i></a>
							</div>
						</div>
						<div class="instructor-image col-md-5 col-sm-6 col-xs-12">
							<img src="img/instructor/big-1.png" alt="" />
						</div>
					</div>
					<div class="tab-pane fade row" id="instructor-2">
						<div class="instructor-details text-left col-md-7 col-xs-12">
							<h4 class="instructor-name">Sobia Khalid</h4>
							<h5 class="instructor-title">Human Resource Manager and Senior Trainer</h5>
							<p>Highly Qualified, Competent, and Energetic personnel service Khalid Approach School of Motoring as a Human Resource Manager for a long time. In case of any type of complaints, she takes care of the situation and tries to solve that wisely and professionally</p>
							<div class="instructor-social fix">
								<a href="https://www.facebook.com/sobia.khalid.3" target="_blank"><i class="icofont icofont-social-facebook"></i></a>
								<a href="tel:+447877611500"><i class="icofont icofont-phone"></i></a>
							</div>
						</div>
						<div class="instructor-image col-md-5 col-sm-6 col-xs-12">
							<img src="img/instructor/big-2.png" alt="" />
						</div>
					</div>
				</div>
				<!-- Instructor Tab List -->
				<ul class="instructor-tab-list fix">
					<li class="active"><a href="#instructor-1" data-toggle="tab"><img src="img/instructor/1.png" alt="" /></a></li>
					<li><a href="#instructor-2" data-toggle="tab"><img src="img/instructor/2.png" alt="" /></a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!-- CTA Area
============================================ -->
<div class="cta-area pb-40 pt-40">
	<div class="container">
		<div class="row">
			<div class="call-to-action text-left col-md-10 col-md-offset-1 col-xs-12">
				<h3><strong>Get exclusive discount on bulk bookings</strong> </h3>
				<a href="https://approachdrivereducation.co.uk/contact.php" class="btn transparent ">contact us</a>
			</div>
		</div>
	</div>
</div>
<?php
include('includes/footer.php');
include('includes/bottom.php');
?>