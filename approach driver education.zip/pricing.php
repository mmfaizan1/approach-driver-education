<?php
$page = "Pricing";
include('includes/top.php');
include('includes/header.php');
?>
<!-- Page Banner Area
============================================ -->
<div class="page-banner-area overlay overlay-black overlay-70">
	<div class="container">
		<div class="row">
			<div class="page-banner text-center col-12">
				<h1>Pricing</h1>
			</div>
		</div>
	</div>
</div>
<!-- Pricing Area
============================================ -->
<div id="pricing-area" class="pricing-area overlay bg-white overlay-black overlay-40 pt-90 pb-60">
	<div class="container">
		<!-- Section Title -->
		<div class="row">
			<div class="section-title title-white text-center col-12 mb-45">
				<h3 class="heading">Driving Lesson Prices</h3>
				<div class="excerpt">
					<p>We offer single lesson booking as well as booking in bulk</p>
				</div>
				<i class="icofont icofont-traffic-light"></i>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-3 col-md-6 col-12 mb-30">
				<div class="single-pricing text-center">
					<div class="pricing-head">
						<h4>Single</h4>
					</div>
					<div class="pricing-price">
						<h2><span>£</span>27</h2>
					</div>
					<ul class="pricing-details">
						<li>1 Hour Lesson Per Day</li>
						<li>Manual/Automatic Driving</li>
						<li>Free Pickup and Drop-off</li>
						<li>Theory + Practical Lessons</li>
					</ul>
					<a href="/contact" class="pricing-action">Book Now</a>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-12 mb-30">
				<div class="single-pricing text-center">
					<div class="pricing-head">
						<h4>Bulk</h4>
					</div>
					<div class="pricing-price">
						<h2><span>£</span>250</h2>
					</div>
					<ul class="pricing-details">
						<li>10 Hours Lessons</li>
						<li>Manual/Automatic Driving</li>
						<li>Free Pickup and Drop-off</li>
						<li>Theory + Practical Lessons</li>
					</ul>
					<a href="/contact" class="pricing-action">Book Now</a>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-12 mb-30">
				<div class="single-pricing text-center">
					<div class="pricing-head">
						<h4>Gold</h4>
					</div>
					<ul class="pricing-details">
						<li>20 Hours Lessons</li>
						<li>Call +44 7501 400022 for further details</li>
					</ul>
					<a href="/contact" class="pricing-action">Book Now</a>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- CTA Area
============================================ -->
<div class="cta-area pb-40 pt-40">
	<div class="container">
		<div class="row">
			<div class="call-to-action text-left col-md-10 col-md-offset-1 col-xs-12">
				<h3><strong>Get exclusive discount on bulk bookings</strong> </h3>
				<a href="https://khalidapproachschoolofmotoring.co.uk/contact.php" class="btn transparent ">contact us</a>
			</div>
		</div>
	</div>
</div>
<?php
include('includes/footer.php');
include('includes/bottom.php');
?>