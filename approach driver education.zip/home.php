<?php
$page = "Home";
include('includes/top.php');
include('includes/header.php');
include('includes/slider.php');
?>

<!-- Feature Area
============================================ -->
<div id="feature-area" class="feature-area bg-gray pt-90 pb-90">
	<div class="container">
		<!-- Section Title -->
		<div class="row">
			<div class="section-title text-center col-xs-12 mb-45">
				<h3 class="heading">our features</h3>
				<div class="excerpt">
					<p>Approach Driver Education formerly Approach School of Motoring is a family business running since 15 years dedicated to safe driving and customer satisfaction.
No matter what your age or experience, at Khalid Approach School of motoring, you can be sure of patient, expert tuition. We tailor your driving lesson to suit you personally which means you avoid stress by learning at your own speed.
We welcome complete novices/nervous drivers, whatever your current driving ability may be; we can devise a plan to prepare you for your test.</p>
				</div>
				<i class="icofont icofont-traffic-light"></i>
			</div>
		</div>
		<div class="row">
			<!-- Left Feature -->
			<div class="feature-wrapper feature-left text-right col-md-4 col-xs-12">
				<div class="single-feature">
					<div class="icon"><i class="icofont icofont-file-spreadsheet"></i></div>
					<div class="text fix">
						<h4>Quick License</h4>
						<p>At Khalid driving School it is 100% safe, easy and legit procedure to learn driving and pass test which in turn allows to get license easily.</p>
					</div>
				</div>
				<div class="single-feature">
					<div class="icon"><i class="icofont icofont-car-alt-4"></i></div>
					<div class="text fix">
						<h4>Safe Driving</h4>
						<p>Approach Driver Education the best driving school in Southall. We teach our students the best practices for safe driving to avoid any uneven situations.</p>
					</div>
				</div>
				<div class="single-feature">
					<div class="icon"><i class="icofont icofont-video-alt"></i></div>
					<div class="text fix">
						<h4>Theoratical Classes</h4>
						<p>We work with students by providing theoratical knowledge leading to practical classes.</p>
					</div>
				</div>
			</div>
			<!-- Feature Image -->
			<div class="feature-image text-center col-md-4 col-xs-12">
				<img src="img/feature.png" alt="feature" />
			</div>
			<!-- Right Feature -->
			<div class="feature-wrapper feature-right text-left col-md-4 col-xs-12">
				<div class="single-feature">
					<div class="icon"><i class="icofont icofont-man-in-glasses"></i></div>
					<div class="text fix">
						<h4>Experience Instructors</h4>
						<p>We have Fully qualified DVSA approved instructors with TOP grades. They help with your driving skills using their experiences</p>
					</div>
				</div>
				<div class="single-feature">
					<div class="icon"><i class="icofont icofont-clock-time"></i></div>
					<div class="text fix">
						<h4>Any Time Any Place</h4>
						<p>We provide free pickup and dropoff lesson service so you do not have to worry about time and place of lessons.</p>
					</div>
				</div>
				<div class="single-feature">
					<div class="icon"><i class="icofont icofont-direction-sign"></i></div>
					<div class="text fix">
						<h4>Learning Roads</h4>
						<p>Teaching road sense is considered a best approach in driving. So, we teach our students by giving lessons on roads and motorway. </p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Funfact Area
============================================ -->
<div class="funfact-area overlay overlay-white overlay-80 pt-90 pb-60">
	<div class="container">
		<div class="row">
			<div class="single-facts text-center col-sm-4 col-xs-12 mb-30">
				<i class="icofont icofont-hat-alt"></i>
				<h1 class="counter plus">500</h1>
				<p>graduted from here</p>
			</div>
			<!-- <div class="single-facts text-center col-sm-3 col-xs-12 mb-30">
				<i class="icofont icofont-user-suited"></i>
				<h1 class="counter">56</h1>
				<p>teachers number</p>
			</div> -->
			<div class="single-facts text-center col-sm-4 col-xs-12 mb-30">
				<i class="icofont icofont-history"></i>
				<h1 class="counter">15</h1>
				<p>years on market</p>
			</div>
			<div class="single-facts text-center col-sm-4 col-xs-12 mb-30">
				<i class="icofont icofont-users-social"></i>
				<h1 class="counter plus">30</h1>
				<p>present students</p>
			</div>
		</div>
	</div>
</div>
<!-- Course Area
============================================ -->
<div id="course-area" class="course-area bg-gray pt-90 pb-60">
	<div class="container">
		<!-- Section Title -->
		<div class="row">
			<div class="section-title text-center col-xs-12 mb-45">
				<h3 class="heading">course category</h3>
				<div class="excerpt">
					<p>We offer variation of courses according to choice of people.</p>
				</div>
				<i class="icofont icofont-traffic-light"></i>
			</div>
		</div>
		<!-- Course Wrapper -->
		<div class="course-wrapper row">
			<div class="col-md-3 col-sm-6 col-xs-12 mb-30 fix">
				<div class="course-item text-center">
					<i class="icofont icofont-car-alt-4"></i>
					<h4>normal driving</h4>
					<p>We work on newbies who want to learn how to drive from basic to advanced level.</p>
				</div>
			</div>
			<div class="col-md-3 col-sm-6 col-xs-12 mb-30 fix">
				<div class="course-item text-center">
					<i class="icofont icofont-ambulance-cross"></i>
					<h4>defensive</h4>
					<p>Approach Driver Education provide defensive driving lessons in southall This course is intended to learn how to drive safe to avoid any intense situation.</p>
				</div>
			</div>
			<div class="col-md-3 col-sm-6 col-xs-12 mb-30 fix">
				<div class="course-item text-center">
					<i class="icofont icofont-fast-delivery"></i>
					<h4>transmission</h4>
					<p>We provide training for both <strong>Manual and Automatic transmission</strong> cars</p>
				</div>
			</div>
			<div class="col-md-3 col-sm-6 col-xs-12 mb-30 fix">
				<div class="course-item text-center">
					<i class="icofont icofont-rocket-alt-2"></i>
					<h4>Theory test preparation</h4>
					<p>We not only provide you practical driving lessons but we help in theory test preparation also.</p>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Video Area
============================================ -->
<!-- <div class="video-area overlay overlay-black overlay-50">
	<div class="container">
		<div class="row">
			<div class="video-content text-center col-xs-12">
				<a class="video-popup" href="https://www.youtube.com/watch?v=ngaeb1jARAY"><i class="icofont icofont-play-alt-2"></i></a>
				<h3>our teaching process</h3>
			</div>
		</div>
	</div>
</div> -->
<!-- Instructor Area
============================================ -->
<div id="instructor-area" class="instructor-area bg-gray pt-90 pb-60">
	<div class="container">
		<!-- Section Title -->
		<div class="row">
			<div class="section-title text-center col-xs-12 mb-45">
				<h3 class="heading">Instructors</h3>
				<div class="excerpt">
					<p>We have DVSA Qualified instructor in southall with Top Grades.</p>
				</div>
				<i class="icofont icofont-traffic-light"></i>
			</div>
		</div>
		<div class="row">
			<div class="col-md-10 col-md-offset-1">
				<!-- Instructor Tab Content -->
				<div class="tab-content">
					<div class="tab-pane fade in active row" id="instructor-1">
						<div class="instructor-details text-left col-md-7 col-xs-12">
							<h4 class="instructor-name">Mohammad Iqbal Khalid</h4>
							<h5 class="instructor-title">Director and Lead Instructor</h5>
							<p>Mohammad Khalid is the director of Approach Driver Education. He is Serving Approach Driver Education from over 15 Years. He is Fully Qualified & Approved Driving Instructor.</p>
							<div class="instructor-social fix">
								<a href="https://www.facebook.com/profile.php?id=100007849806151" target="_blank"><i class="icofont icofont-social-facebook"></i></a>
								<a href="mailto:mkhalid9789@gmail.com"><i class="icofont icofont-email"></i></a>
								<a href="tel:+447501400022"><i class="icofont icofont-phone"></i></a>
							</div>
						</div>
						<div class="instructor-image col-md-5 col-sm-6 col-xs-12">
							<img src="img/instructor/big-1.png" alt="" />
						</div>
					</div>
					<div class="tab-pane fade row" id="instructor-2">
						<div class="instructor-details text-left col-md-7 col-xs-12">
							<h4 class="instructor-name">Sobia Khalid</h4>
							<h5 class="instructor-title">Human Resource Manager and Senior Trainer</h5>
							<p>Highly Qualified, Competent, and Energetic personnel service Approach Driver Education as a Human Resource Manager for a long time. In case of any type of complaints, she takes care of the situation and tries to solve that wisely and professionally</p>
							<div class="instructor-social fix">
								<a href="https://www.facebook.com/sobia.khalid.3" target="_blank"><i class="icofont icofont-social-facebook"></i></a>
								<a href="tel:+447877611500"><i class="icofont icofont-phone"></i></a>
							</div>
						</div>
						<div class="instructor-image col-md-5 col-sm-6 col-xs-12">
							<img src="img/instructor/big-2.png" alt="" />
						</div>
					</div>
				</div>
				<!-- Instructor Tab List -->
				<ul class="instructor-tab-list fix">
					<li class="active"><a href="#instructor-1" data-toggle="tab"><img src="img/instructor/1.png" alt="" /></a></li>
					<li><a href="#instructor-2" data-toggle="tab"><img src="img/instructor/2.png" alt="" /></a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!-- CTA Area
============================================ -->
<div class="cta-area pb-40 pt-40">
	<div class="container">
		<div class="row">
			<div class="call-to-action text-left col-md-10 col-md-offset-1 col-xs-12">
				<h3><strong>Get exclusive discount on bulk bookings</strong> </h3>
				<a href="https://khalidapproachschoolofmotoring.co.uk/contact.php" class="btn transparent ">contact us</a>
			</div>
		</div>
	</div>
</div>

<?php
include('includes/footer.php');
include('includes/bottom.php');
?>