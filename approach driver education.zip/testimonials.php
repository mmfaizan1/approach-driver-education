<?php
$page = "Testimonials";
include('includes/top.php');
include('includes/header.php');
?>
<!-- Page Banner Area
============================================ -->
<div class="page-banner-area overlay overlay-black overlay-70">
	<div class="container">
		<div class="row">
			<div class="page-banner text-center col-xs-12">
				<h1>Testimonials</h1>
				<!-- <ul>
					<li><a href="#">home</a></li>
					<li><span>about us</span></li>
				</ul> -->
			</div>
		</div>
	</div>
</div>
<!-- Testimonial Area
============================================ -->
<div id="testimonial-area" class="testimonial-area overlay overlay-white overlay-80 text-center pt-90 pb-90">
	<div class="container">
		<div class="row">
			<div class="section-title text-center col-xs-12 mb-45">
				<h3 class="heading">testimonials</h3>
				<div class="excerpt">
					<p>See what our client says about us.</p>
				</div>
				<i class="icofont icofont-traffic-light"></i>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8 col-md-offset-2 col-xs-12">
				<!-- Testimonial Image Slider -->
				<div class="ti-slider mb-40">
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/28.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/5.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/1.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/2.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/3.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/4.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/5.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/6.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/7.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/8.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/9.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/10.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/11.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/12.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/13.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/14.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/15.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/16.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/17.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/18.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/19.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/20.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/21.png" alt="" /></div></div>
					<div class="single-slide"><div class="image fix"><img src="img/testimonial/22.png" alt="" /></div></div>
				</div>
				<!-- Testimonial Content Slider -->
				<div class="tc-slider">
					<div class="single-slide">
						<p>He is very good, patience, respectful, trustworthy and a very humble (instructor) man. I knew nothing about driving but with Mohammed's patience I was able to pass both theory and my practical test. Am very happy God richly bless you with more knowledge. Keep up the good work!!!</p>
						<h5>Nancy</h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>Passed first time, thank you for giving me the confidence to be a safe driver for life!</p>
						<h5>Isabell</h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>Your staff were attentive to my demands. I was given the confidence to get on the road again. I would recommend you to anyone who want to improve their driving.</p>
						<h5>Joe</h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>I would definitely recommend Approach Driver Education because instructors were superb! They made me pass the first time. I couldn’t be happier! Thank you.</p>
						<h5>Amir Khan</h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>I want to say a massive thank you to my instructor for his patience and willingness to adapt his teaching methods to work with me. He is an absolute diamond!</p>
						<h5>Jannat</h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>Following an accident I lost all confidence in driving. My instructor took over teaching me to drive and built my confidence back up and got me through my test. Thanks.</p>
						<h5>Jennie Grey</h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>I did not even knew about how to start the engine. After getting coaching from Mr. Khalid I can drive a car with great confidence and ease. I highely recommend him.</p>
						<h5></h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>Getting failed twice in driving test I went to khalid approach school of motoring and then I got my test passed in the first attempt.</p>
						<h5></h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>I was so nervous after spending so many weeks for my first driving lesson, Khalid made me comfortable with 15-20 mins. By the time I took my test I was feeling extremely confident. I strongly recommend learning to drive with Khalid.</p>
						<h5>Richard</h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>What can I say…No words to say..Such a great driving Instructor Khalid is…I passed my test and I have valid UK Driving licence 1000 salutes to his driving skills and to his driving school (Approach school of motoring).</p>
						<h5>Niva Shah</h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>I was so upset after being let down by my previous instructor. My friend suggested speaking to Khalid. I called Khalid and booked my first lesson, he made me so comfortable and he was so understanding. He is a great teacher. I passed my test so easily. Thank you so much Approach Driving School J I will surely recommend others.</p>
						<h5>Priya</h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>I thoroughly enjoyed the lessons, thanks for all the help you have given me in the beginning after I came from another tutor with bad habits. You had easier ways to help me remember things and I found each lesson very helpful.Thanks again…!!!</p>
						<h5>Sachin</h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p> I would like to say a massive thank you to Khalid for his time, patience and excellent humour all of which helped me pass my practical test today 03/12/2013, would highly recommend him to anyone, so Khalid you are a top man and thanks again.</p>
						<h5>Samuel</h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>Khalid is brilliant, having an excellent teaching ability, I had a great time with him in the car. He has got amazing driving skills as well as a great sense of teaching. You are doing very well Sir. You really saved my time and money. Wish you Best of Luck.</p>
						<h5>Bill</h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>When I started I was so nervous. I could have not been able to drive if Mr Khaid did not come in my life. He pulled my confidence to 100 and then I passed my driving test.</p>
						<h5></h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>The safe and comfortable driving classes at Approach School led me to pass my driving test the very first time. Recommended 10000</p>
						<h5></h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>When I First started driving, I was not able to steer the car for even a feet. But after joining Approach School, I now been able to drive comfortably.</p>
						<h5></h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>After couple of failed attempts I joined Khalid for my driving lessons. He made me a pro driver and I passed my test in the first attempt. I thank him for saving me.</p>
						<h5></h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>Outstanding Experience with Approach Driver Education. They are equipped with a wide range of skills and are flexible with booking hours. Just go here for your ease.</p>
						<h5></h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>The lessons were great. Helped me in polishing out my driving skills. Now I can burn the roads with my driving. All creadit goes to Approach School</p>
						<h5></h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>I found Mr Khalid very calm and patient whenever I drove foolishly. Highely Recommend.</p>
						<h5></h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>Both my theory and practical tests are passed because of Khalid. I highly recommend Approach Driver Education to others.</p>
						<h5></h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>M Khalid helped me in ripping of my bad driving habits and now I drive everyday with best practices.</p>
						<h5></h5>
						<span>Student</span>
					</div>
					<div class="single-slide">
						<p>Just had a session with Khalid. He is very knowledgeable, kind and understanding. I now feel very confident that I have choosen the right institute.</p>
						<h5></h5>
						<span>Student</span>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Slider Arrows -->
	<button class="ts-arrows ts-prev"><i class="icofont icofont-caret-left"></i></button>
	<button class="ts-arrows ts-next"><i class="icofont icofont-caret-right"></i></button>
</div>
<!-- CTA Area
============================================ -->
<div class="cta-area pb-40 pt-40">
	<div class="container">
		<div class="row">
			<div class="call-to-action text-left col-md-10 col-md-offset-1 col-xs-12">
				<h3><strong>Get exclusive discount on bulk bookings</strong> </h3>
				<a href="https://approachdrivereducation.co.uk/contact.php" class="btn transparent ">contact us</a>
			</div>
		</div>
	</div>
</div>
<?php
include('includes/footer.php');
include('includes/bottom.php');
?>