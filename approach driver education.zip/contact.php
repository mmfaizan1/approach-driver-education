<?php
$page = "Contact";
include('includes/top.php');
include('includes/header.php');
?>
<!-- Page Banner Area
============================================ -->
<div class="page-banner-area overlay overlay-black overlay-70">
	<div class="container">
		<div class="row">
			<div class="page-banner text-center col-xs-12">
				<h1>Contact us</h1>
			</div>
		</div>
	</div>
</div>
<!-- Contatc Area
============================================ -->
<div id="contact-area" class="contact-area bg-gray">
	<div class="container pb-90 pt-90">
		<!-- Section Title -->
		<div class="row">
			<div class="section-title text-center col-xs-12 mb-45">
				<h3 class="heading">touch in Approach Driver Education</h3>
				<div class="excerpt">
					<p>To reach us, find one of the methods that suits you!</p>
				</div>
				<i class="icofont icofont-traffic-light"></i>
			</div>
		</div>
		<div class="row">
			<!-- Contact Info -->
			<div class="contact-info col-md-4 col-sm-5 col-xs-12">
				<div class="single-info text-left fix">
					<div class="icon"><i class="icofont icofont-phone"></i></div>
					<div class="content fix">
						<h5>call us</h5>
						<p><a href="tel:+447501400022">+44 7501 400022</a></p><p><a href="tel:+447877611500">+44 7877 611500</a></p><p></p>
					</div>
				</div>
			</div>
			<div class="contact-info col-md-4 col-sm-5 col-xs-12">
				<div class="single-info text-left fix">
					<div class="icon"><i class="icofont icofont-envelope"></i></div>
					<div class="content fix">
						<h5>your message</h5>
						<p><a href="mailto:mkhalid9789@gmail.com">mkhalid9789@gmail.com</a></p><p></p>
					</div>
				</div>
			</div>
			<div class="contact-info col-md-4 col-sm-5 col-xs-12">
				<div class="single-info text-left fix">
					<div class="icon"><i class="icofont icofont-location-pin"></i></div>
					<div class="content fix">
						<h5>our location</h5>
						<p>Allendale Avenue London, <br />United Kingdom</p>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="contact-info col-md-4 col-sm-5 col-xs-12">
				<div class="single-info text-left fix">
					<div class="icon"><i class="icofont icofont-contacts"></i></div>
					<div class="content fix">
						<h5>Find us on facebook</h5>
						<p><a href="https://www.facebook.com/Khalidapproachschoolofmotoringcouk-2080687032201140/" target="_blank">Approach Driver <br> Education</a></p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- CTA Area
============================================ -->
<div class="cta-area pb-40 pt-40">
	<div class="container">
		<div class="row">
			<div class="call-to-action text-left col-md-10 col-md-offset-1 col-xs-12">
				<h3><strong>Get exclusive discount on bulk bookings</strong> </h3>
				<a href="https://approachdrivereducation.co.uk/contact.php" class="btn transparent ">contact us</a>
			</div>
		</div>
	</div>
</div>
<?php
include('includes/footer.php');
include('includes/bottom.php');
?>