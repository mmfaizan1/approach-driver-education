<?php
$page = "FAQ";
include('includes/top.php');
include('includes/header.php');
?>


<!-- Page Banner Area
============================================ -->
<div class="page-banner-area overlay overlay-black overlay-70">
	<div class="container">
		<div class="row">
			<div class="page-banner text-center col-xs-12">
				<h1>FAQ</h1>
				<!-- <ul>
					<li><a href="#">home</a></li>
					<li><span>about us</span></li>
				</ul> -->
			</div>
		</div>
	</div>
</div>
<!-- Ask me Tell me Area
============================================ -->
<div id="faq-area" class="faq-area bg-white pt-90 pb-60">
	<div class="container">
		<!-- Section Title -->
		<div class="row">
			<div class="section-title text-center col-xs-12 mb-45">
				<h3 class="heading">Tell Me Questions</h3>
				<div class="excerpt">
					<p>Tell me driving questions</p>
				</div>
				<i class="icofont icofont-traffic-light"></i>
			</div>
		</div>
		<div class="row">
			<div class="faq-image col-md-12">
				<!-- 16:9 aspect ratio -->
				<div class="embed-responsive embed-responsive-16by9">
				  <iframe class="embed-responsive-item" width="560" height="315" src="https://www.youtube.com/embed/uh8slnP76-w" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
				</div>
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="col-md-6">
				<div class="panel-group" id="ask-l">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="true" data-parent="#ask-l" href="#ask-1">Tell me how you’d check that the brakes are working before starting a journey.</a></h4>
						</div>
						<div id="ask-1" class="panel-collapse collapse in">
							<div class="panel-body">
								<p>Brakes should not feel spongy or slack. Brakes should be tested as you set off.Vehicle should not pull to one side.</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="false" data-parent="#ask-l" href="#ask-2">Tell me how you make sure your head restraint is correctly adjusted so it provides the best protection in the event of a crash.</a></h4>
						</div>
						<div id="ask-2" class="panel-collapse collapse">
							<div class="panel-body">
								<p>The head restraint should be adjusted so the rigid part of the head restraint is at least as high as the eye or top of the ears, and as close to the back of the head as is comfortable. Note: Some restraints might not be adjustable.</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="false" data-parent="#ask-l" href="#ask-3">Tell me how you’d check that the headlights and tail lights are working. You don’t need to exit the vehicle.</a></h4>
						</div>
						<div id="ask-3" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Explain you’d operate the switch (turn on ignition if necessary), then walk roundvehicle (as this is a ‘tell me’ question, you don’t need to physically check the lights).</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="false" data-parent="#ask-l" href="#ask-4">Tell me how you’d check the direction indicators are working. You don’t need to exit the vehicle.</a></h4>
						</div>
						<div id="ask-4" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Explain you’d operate the switch (turn on ignition if necessary), and then walk round vehicle (as this is a ‘tell me’ question, you don’t need to physically check the lights).</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="false" data-parent="#ask-l" href="#ask-5">Tell me how you’d check the power-assisted steering is working before starting a journey.</a></h4>
						</div>
						<div id="ask-5" class="panel-collapse collapse">
							<div class="panel-body">
								<p>If the steering becomes heavy, the system may not be working properly. Before starting a journey, 2 simple checks can be made. Gentle pressure on the steering wheel, maintained while the engine is started,should result in a slight but noticeable movement as the system begins to operate. Alternatively turning the steering wheel just after moving off will give an immediate indication that the power assistance is functioning.</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="false" data-parent="#ask-l" href="#ask-6">Tell me how you switch your headlight from dipped to main beam and explain how you’d know the main beam is on.</a></h4>
						</div>
						<div id="ask-6" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Operate switch (with ignition or engine on if necessary), check with main beam warning light.</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="true" data-parent="#ask-l" href="#ask-7">Open the bonnet and tell me how you’d check that the engine has sufficient engine coolant.</a></h4>
						</div>
						<div id="ask-7" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Identify high and low level markings on header tank where fitted or radiator filler cap, and describe how to top up to correct level.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div class="panel-group" id="ask">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="false" data-parent="#ask" href="#ask-8">Tell me where you’d find the information for the recommended tyre pressures for this car and how tyre pressures should be checked.</a></h4>
						</div>
						<div id="ask-8" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Manufacturer’s guide, use a reliable pressure gauge, check and adjust pressureswhen tyres are cold, don’t forget spare tyre, remember to refit valve caps.</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="false" data-parent="#ask" href="#ask-9">Tell me how you’d check the tyres to ensure that they have sufficient tread depth and that their general condition is safe to use on the road.</a></h4>
						</div>
						<div id="ask-9" class="panel-collapse collapse">
							<div class="panel-body">
								<p>No cuts and bulges, 1.6mm of tread depth across the central three-quarters of the breadth of the tyre, and around the entire outer circumference of the tyre.</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="false" data-parent="#ask" href="#ask-10">Tell me how you’d know if there was a problem with your anti-lock braking system.</a></h4>
						</div>
						<div id="ask-10" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Warning light should illuminate if there is a fault with the anti-lock braking system.</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="false" data-parent="#ask" href="#ask-11">Tell me how you’d check the brake lights are working on this car.</a></h4>
						</div>
						<div id="ask-11" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Explain you’d operate the brake pedal, make use of reflections in windows or doors, or ask someone to help.</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="false" data-parent="#ask" href="#ask-12">Tell me how you’d switch on the rear fog light(s) and explain when you’d use it/them. You don’t need to exit the vehicle.</a></h4>
						</div>
						<div id="ask-12" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Operate switch (turn on dipped headlights and ignition if necessary). Check warninglight is on. Explain use.</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="false" data-parent="#ask" href="#ask-13">Open the bonnet and tell me how you’d check that the engine has sufficient oil.</a></h4>
						</div>
						<div id="ask-13" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Identify dipstick/oil level indicator, describe check of oil level against the minimum and maximum markers.</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="false" data-parent="#ask" href="#ask-14">Open the bonnet and tell me how you’d check that you have a safe level of hydraulic brake fluid.</a></h4>
						</div>
						<div id="ask-14" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Identify reservoir, check level against high and low markings</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Show me Area
============================================ -->
<div id="faq-area" class="faq-area bg-white pt-90 pb-60">
	<div class="container">
		<!-- Section Title -->
		<div class="row">
			<div class="section-title text-center col-xs-12 mb-45">
				<h3 class="heading">Show Me Questions</h3>
				<div class="excerpt">
					<p>show me driving questions</p>
				</div>
				<i class="icofont icofont-traffic-light"></i>
			</div>
		</div>
		<div class="row">
			<div class="faq-image col-md-12">
				<!-- 16:9 aspect ratio -->
				<div class="embed-responsive embed-responsive-16by9">
				  <iframe class="embed-responsive-item" width="560" height="315" src="https://www.youtube.com/embed/damj01nXcZU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
				</div>
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="col-md-6">
				<div class="panel-group" id="ask-l">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a aria-expanded="false">When it’s safe to do so, can you show me how you wash and clean the rear windscreen?</a></h4>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a aria-expanded="false">When it’s safe to do so, can you show me how you’d switch on your dipped headlights?</a></h4>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a aria-expanded="false">When it’s safe to do so, can you show me how you’d operate the horn?</a></h4>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a aria-expanded="false">When it’s safe to do so, can you show me how you’d open and close the side window?</a></h4>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div class="panel-group" id="ask">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a aria-expanded="false">When it’s safe to do so, can you show me how you wash and clean the front windscreen?</a></h4>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a aria-expanded="false">When it’s safe to do so, can you show me how you’d set the rear demister?</a></h4>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a aria-expanded="false">When it’s safe to do so, can you show me how you’d demist the front windscreen?</a></h4>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- FAQ Area
============================================ -->
<div id="faq-area" class="faq-area bg-white pt-90 pb-60">
	<div class="container">
		<!-- Section Title -->
		<div class="row">
			<div class="section-title text-center col-xs-12 mb-45">
				<h3 class="heading">Frequently asked questions</h3>
				<div class="excerpt">
					<p>Some of the frequently asked questions</p>
				</div>
				<i class="icofont icofont-traffic-light"></i>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<div class="panel-group" id="faq">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="true" data-parent="#faq" href="#faq-1">How old do I need to be to take driver’s education?</a></h4>
						</div>
						<div id="faq-1" class="panel-collapse collapse in">
							<div class="panel-body">
								<p>According to the government of the UK, you must be at least 17 if you want to take drivers education.</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="false" data-parent="#faq" href="#faq-2">When does the driving portion of the course start?</a></h4>
						</div>
						<div id="faq-2" class="panel-collapse collapse">
							<div class="panel-body">
								<p>You will start driving portion soon after you finish a theoretical demonstration of vehicle and  after you will get sufficient basics of driving.</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="false" data-parent="#faq" href="#faq-3">My parents are concerned for my safety, but I don’t want to be bored.</a></h4>
						</div>
						<div id="faq-3" class="panel-collapse collapse">
							<div class="panel-body">
								<p>We have a team of highly qualified instructors qualified from DSA. We practice and teach best practices and we believe in teaching safe driving so you don’t have to worry about something.</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="false" data-parent="#faq" href="#faq-4">Do I have to use my parents care, or does the school provide one?</a></h4>
						</div>
						<div id="faq-4" class="panel-collapse collapse">
							<div class="panel-body">
								<p>As said earlier you are totally safe while with us. So, you don’t need any type of care and supervision while you are engaged with us.</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="false" data-parent="#faq" href="#faq-5">Which areas do you cover?</a></h4>
						</div>
						<div id="faq-5" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Areas We Cover are – Greenford, Southall,Hayes,Perivale,Hanwell.</p> Prices of other areas are different because of mileage</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title"><a data-toggle="collapse" aria-expanded="false" data-parent="#faq" href="#faq-6">What are the special training hours?</a></h4>
						</div>
						<div id="faq-6" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Approach Driver Education also train students at weekends and evenings. These lessons are fractionally more but negotiable</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="faq-image col-md-6">
				<img src="img/faq.png" alt="" />
			</div>
		</div>
	</div>
</div>
<!-- CTA Area
============================================ -->
<div class="cta-area pb-40 pt-40">
	<div class="container">
		<div class="row">
			<div class="call-to-action text-left col-md-10 col-md-offset-1 col-xs-12">
				<h3><strong>Get exclusive discount on bulk bookings</strong> </h3>
				<a href="https://approachdrivereducation.co.uk/contact.php" class="btn transparent ">contact us</a>
			</div>
		</div>
	</div>
</div>
<?php
include('includes/footer.php');
include('includes/bottom.php');
?>